<?php
defined('BASEPATH') OR exit('What Are You Looking For ?');
?>
<div class="panel panel-success"> 
	<div class="panel-heading"> 
		<h3 class="panel-title">Pesan singkat</h3> 
	</div> 
	<div class="panel-body"> <?php echo $data;?> </div> 
	<div class="panel-footer"></div> 
</div>