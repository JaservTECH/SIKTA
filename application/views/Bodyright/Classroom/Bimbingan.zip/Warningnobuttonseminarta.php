<?php
defined('BASEPATH') OR exit('What Are You Looking For ?');
?>
<div class="panel panel-warning"> 
	<div class="panel-heading"> 
		<h3 class="panel-title">Pesan Singkat</h3> 
	</div> 
	<div class="panel-body"> <?php echo $message;?> </div> 
	<div class="panel-footer">
	</div> 
</div>